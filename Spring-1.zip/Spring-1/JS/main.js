//alert ("¡Bienvenido a Fono-Fon!");

//console.log ("hola")

const catalogo = [
    {
        id: 1,
        title: "Iphone 15",
        price: 1049,
        description: "Ligero, Resistente y la mejor camara",
        category: "celulares",
        image: "https://images.macrumors.com/article-new/2023/09/iPhone-15-General-Feature-Black.jpg",
        rating: {
            rate: 3.9,
            count: 120,
        },
    },]


let card = document.getElementById("catalogo");

catalogo.map((producto) => {
    card.innerHTML+= `
        <div class="col-md-3 mb-3">
            <div class="card h-100 text-center p-4" key= ${producto.id} >
                <img src= ${producto.image} className="card-img-top" alt= ${producto.title} height="100%" width="100%" border-radious="20px" />
                <div class="card-body">
                    <h5 class="card-title mb-0"> ${producto.title.substring(0,40)}</h5>
                    <p class="card-title mb-0"> ${producto.description.substring(0,50)}</p>
                    <p class="card-text lead fw-bold">$ ${producto.price} </p>
                </div>
                <a href="#" class="btn btn-outline-dark"> Me interesa </a>
            </div>
        </div>
    `
});