alert("¡Bienvenido a Fono-Fon! Un proyecto con mucho cariño y dedicacion");

console.log ("Gracias Mati por todo")